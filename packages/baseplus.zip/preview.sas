filename PC5C9E00 list;
 %put NOTE- ;
 %put NOTE: Preview of the BasePlus package, version 3.2.0, license MIT;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-28T12:00:14; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;
%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include PC5C9E00(packagemetadata.sas) / nosource2; 
data _null_;                                                 
  if strip(symget("helpKeyword")) = " " then                 
    do until (EOF);                                          
      infile PC5C9E00(description.sas) end = EOF;  
      input;                                                 
      put _infile_;                                          
    end;                                                     
  else stop;                                                 
run;                                                         
data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
007_macro/007/macro/bppipe.sas/bppipe/'%bppipe()'
007_macro/007/macro/deduplistc.sas/deduplistc/'%deduplistc()'
007_macro/007/macro/deduplistp.sas/deduplistp/'%deduplistp()'
007_macro/007/macro/deduplists.sas/deduplists/'%deduplists()'
007_macro/007/macro/deduplistx.sas/deduplistx/'%deduplistx()'
007_macro/007/macro/dirsandfiles.sas/dirsandfiles/'%dirsandfiles()'
007_macro/007/macro/functionexists.sas/functionexists/'%functionexists()'
007_macro/007/macro/getvars.sas/getvars/'%getvars()'
007_macro/007/macro/intslist.sas/intslist/'%intslist()'
007_macro/007/macro/ldsn.sas/ldsn/'%ldsn()'
007_macro/007/macro/ldsnm.sas/ldsnm/'%ldsnm()'
007_macro/007/macro/lvarnm.sas/lvarnm/'%lvarnm()'
007_macro/007/macro/lvarnmlab.sas/lvarnmlab/'%lvarnmlab()'
007_macro/007/macro/qdeduplistx.sas/qdeduplistx/'%qdeduplistx()'
007_macro/007/macro/qgetvars.sas/qgetvars/'%qgetvars()'
007_macro/007/macro/qzipevalf.sas/qzipevalf/'%qzipevalf()'
007_macro/007/macro/raincloudplot.sas/raincloudplot/'%raincloudplot()'
007_macro/007/macro/repeattxt.sas/repeattxt/'%repeattxt()'
007_macro/007/macro/splitdsintoblocks.sas/splitdsintoblocks/'%splitdsintoblocks()'
007_macro/007/macro/splitdsintoparts.sas/splitdsintoparts/'%splitdsintoparts()'
007_macro/007/macro/symdelglobal.sas/symdelglobal/'%symdelglobal()'
007_macro/007/macro/unziparch.sas/unziparch/'%unziparch()'
007_macro/007/macro/unziplibrary.sas/unziplibrary/'%unziplibrary()'
007_macro/007/macro/ziparch.sas/ziparch/'%ziparch()'
007_macro/007/macro/zipevalf.sas/zipevalf/'%zipevalf()'
007_macro/007/macro/ziplibrary.sas/ziplibrary/'%ziplibrary()'
008_format/008/format/bool.sas/bool/'$bool.'
008_format/008/format/boolz.sas/boolz/'$boolz.'
008_format/008/format/ceil.sas/ceil/'$ceil.'
008_format/008/format/floor.sas/floor/'$floor.'
008_format/008/format/int.sas/int/'$int.'
009_functions/009/functions/arrfill.sas/arrfill/'arrfill()'
009_functions/009/functions/arrfillc.sas/arrfillc/'arrfillc()'
009_functions/009/functions/arrmissfill.sas/arrmissfill/'arrmissfill()'
009_functions/009/functions/arrmissfillc.sas/arrmissfillc/'arrmissfillc()'
009_functions/009/functions/arrmisstoleft.sas/arrmisstoleft/'arrmisstoleft()'
009_functions/009/functions/arrmisstoleftc.sas/arrmisstoleftc/'arrmisstoleftc()'
009_functions/009/functions/arrmisstoright.sas/arrmisstoright/'arrmisstoright()'
009_functions/009/functions/arrmisstorightc.sas/arrmisstorightc/'arrmisstorightc()'
009_functions/009/functions/bracketsc.sas/bracketsc/'bracketsc()'
009_functions/009/functions/bracketsn.sas/bracketsn/'bracketsn()'
009_functions/009/functions/catxfc.sas/catxfc/'catxfc()'
009_functions/009/functions/catxfi.sas/catxfi/'catxfi()'
009_functions/009/functions/catxfj.sas/catxfj/'catxfj()'
009_functions/009/functions/catxfn.sas/catxfn/'catxfn()'
009_functions/009/functions/deldataset.sas/deldataset/'deldataset()'
009_functions/009/functions/semicolonc.sas/semicolonc/'semicolonc()'
009_functions/009/functions/semicolonn.sas/semicolonn/'semicolonn()'
010_formats/010/formats/bpklenght.sas/bpklenght/'$bpklenght.'
010_formats/010/formats/bplenght.sas/bplenght/'$bplenght.'
010_formats/010/formats/brackets.sas/brackets/'$brackets.'
010_formats/010/formats/semicolon.sas/semicolon/'$semicolon.'
011_proto/011/proto/qsortincbyprocproto.sas/qsortincbyprocproto/'qsortincbyprocproto()'
012_functions/012/functions/frommissingtonumberbs.sas/frommissingtonumberbs/'frommissingtonumberbs()'
012_functions/012/functions/fromnumbertomissing.sas/fromnumbertomissing/'fromnumbertomissing()'
012_functions/012/functions/quicksort4notmiss.sas/quicksort4notmiss/'quicksort4notmiss()'
012_functions/012/functions/quicksorthash.sas/quicksorthash/'quicksorthash()'
012_functions/012/functions/quicksorthashsddv.sas/quicksorthashsddv/'quicksorthashsddv()'
012_functions/012/functions/quicksortlight.sas/quicksortlight/'quicksortlight()'
013_macro/013/macro/date.sas/date/'%date()'
013_macro/013/macro/datetime.sas/datetime/'%datetime()'
013_macro/013/macro/downloadfilesto.sas/downloadfilesto/'%downloadfilesto()'
013_macro/013/macro/expanddatasetslist.sas/expanddatasetslist/'%expanddatasetslist()'
013_macro/013/macro/filepath.sas/filepath/'%filepath()'
013_macro/013/macro/finddswithvarval.sas/finddswithvarval/'%finddswithvarval()'
013_macro/013/macro/fmt.sas/fmt/'%fmt()'
013_macro/013/macro/generateoneliners.sas/generateoneliners/'%generateoneliners()'
013_macro/013/macro/gettitle.sas/gettitle/'%gettitle()'
013_macro/013/macro/iffunc.sas/iffunc/'%iffunc()'
013_macro/013/macro/infmt.sas/infmt/'%infmt()'
013_macro/013/macro/letters.sas/letters/'%letters()'
013_macro/013/macro/libpath.sas/libpath/'%libpath()'
013_macro/013/macro/minclude.sas/minclude/'%minclude()'
013_macro/013/macro/monthshift.sas/monthshift/'%monthshift()'
013_macro/013/macro/replist.sas/replist/'%replist()'
013_macro/013/macro/time.sas/time/'%time()'
013_macro/013/macro/today.sas/today/'%today()'
013_macro/013/macro/translate.sas/translate/'%translate()'
013_macro/013/macro/tranwrd.sas/tranwrd/'%tranwrd()'
013_macro/013/macro/unifyvarscasesize.sas/unifyvarscasesize/'%unifyvarscasesize()'
013_macro/013/macro/worklib.sas/worklib/'%worklib()'
013_macro/013/macro/workpath.sas/workpath/'%workpath()'
;;;;
run;
data _null_;                                                                        
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;      
if NOBS = 0 then do; 
put; put ' *> No preview. Try %previewPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                  
   set WORK._last_ end = EOFDS nobs = NOBS;                                         
   length memberX $ 1024;                                                           
   memberX = cats("_",folder,".",file);                                             
   call execute("data _null_;                                                    ");
   call execute('infile PC5C9E00(' || strip(memberX) || ') end = EOF;  ');
   call execute("    do until(EOF);                                              ");
   call execute("      input;                                                    ");
   call execute("      put _infile_;                                             ");
   call execute("    end;                                                        ");
   call execute("  put "" "" / "" "";                                            ");
   call execute("  stop;                                                         ");
   call execute("run;                                                            ");
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 
%put NOTE: Preview of the BasePlus package, version 3.2.0, license MIT;
%put NOTE- *** END ***;
/* preview.sas end */
