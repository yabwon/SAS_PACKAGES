/*** HELP START ***//*
 
## >>> `bracketsN()` function: <<< <a name="bracketsn-function"></a> #######################  

The **bracketsN()** function is internal function used by the *brackets* format.
Returns character value of length 34.
 
### SYNTAX: ###################################################################

The basic syntax is the following:
~~~~~~~~~~~~~~~~~~~~~~~sas
bracketsN(X)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `X` - Numeric value.

---
*//*** HELP END ***/

  function bracketsN(x) $ 34;
    return ( cats("(", x, ")") );
  endsub;

