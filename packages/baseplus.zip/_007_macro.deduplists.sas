
/*** HELP START ***//*
 
## >>> `%dedupListS()` macro: <<< <a name="deduplists-macro"></a> #######################

The `%dedupListS()` macro deletes duplicated values from 
a *SPACE-separated* list of values. List, including separators,
can be no longer than a value carried by a single macro variable.

Returned value is *unquoted*.

The `%dedupListS()` macro executes like a pure macro code.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%dedupListS(
 list of space-separated values
)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `list` - A list of *space-separated* values. 

*//*** HELP END ***/

%macro dedupListS()/parmbuff minoperator mindelimiter=' ';
  %local _wc_ _I_ _element_ _list_ _sep_;
  %let _sep_=%str( );
  %if %superq(syspbuff) ne %str(%(%)) %then
    %do;
      %let syspbuff = %qsubstr(&syspbuff., 2, %eval(%length(&syspbuff.)-2));
      %let _wc_ = %qsysfunc(countw(&syspbuff., &_sep_.));
      %let _list_ = %qscan(&syspbuff., 1, &_sep_.);
      %do _I_ = 2 %to &_wc_.;
        %let _element_ = %qscan(&syspbuff., &_I_, &_sep_.);
        %if (%superq(_element_) ne ) %then
          %if not(%superq(_element_) in %superq(_list_)) %then
            %do;
              %let _list_ = &_list_.&_sep_.&_element_.;
            %end;
      %end;
    %end;
%unquote(&_list_.)
%mend dedupListS;

/*** HELP START ***//*
 
### EXAMPLES AND USECASES: ####################################################

**EXAMPLE 1.** Basic use-case one. 
    Delete duplicated values from a list.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
  %put *%dedupListS(a b  c   b    c)*;

  %put *%dedupListS(a b,c b,c)*;

  %put *%dedupListS(%str(a b c b c))*;

  %put *%dedupListS(%str(a) %str(b) %str(c) b c)*;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 2.** Macro variable as an argument. 
    Delete duplicated values from a list.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
  %let list = 4 5 6 1 2 3 1 2 3 4 5 6;
  %put *%dedupListS(&list.)*;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/**###################################################################**/
/*                                                                     */
/*  Copyright Bartosz Jablonski, since October 2020.                   */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes with absolutely no warranty whatsoever.               */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*  However, if you decide to use it don't forget to mention author.   */
/*  Bartosz Jablonski (yabwon@gmail.com)                               */
/*                                                                     */
/**###################################################################**/
