/*** HELP START ***//*
 
## >>> `semicolonN()` function: <<< <a name="semicolonn-function"></a> #######################  

The **semicolonN()** function is internal function used by the *semicolon* format.
Returns character value of length 33.
 
### SYNTAX: ###################################################################

The basic syntax is the following:
~~~~~~~~~~~~~~~~~~~~~~~sas
semicolonN(X)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `X` - Numeric value.

---

*//*** HELP END ***/

  function semicolonN(x) $ 33;
    return ( cats(x, ";") );
  endsub;

