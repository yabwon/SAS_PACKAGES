filename PC5C9E00 list;
 %put NOTE- ;
 %put NOTE: Help for package BasePlus, version 3.2.0, license MIT;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-28T12:00:14; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;
%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include PC5C9E00(packagemetadata.sas) / nosource2; 
data _null_;                                                               
  if strip(symget("helpKeyword")) = " " then                               
    do until (EOF);                                                        
      infile PC5C9E00(description.sas) end = EOF;                
      input;                                                               
      if upcase(strip(_infile_)) =: "DESCRIPTION END:"   then printer = 0; 
      if printer then put "| " _infile_;                                   
      if upcase(strip(_infile_)) =: "DESCRIPTION START:" then printer = 1; 
    end;                                                                   
  else stop;                                                               
  put ; put "  Package contains: "; 
put @5 "1." @10 "macro " @21 "bppipe ";
put @5 "2." @10 "macro " @21 "deduplistc ";
put @5 "3." @10 "macro " @21 "deduplistp ";
put @5 "4." @10 "macro " @21 "deduplists ";
put @5 "5." @10 "macro " @21 "deduplistx ";
put @5 "6." @10 "macro " @21 "dirsandfiles ";
put @5 "7." @10 "macro " @21 "functionexists ";
put @5 "8." @10 "macro " @21 "getvars ";
put @5 "9." @10 "macro " @21 "intslist ";
put @5 "10." @10 "macro " @21 "ldsn ";
put @5 "11." @10 "macro " @21 "ldsnm ";
put @5 "12." @10 "macro " @21 "lvarnm ";
put @5 "13." @10 "macro " @21 "lvarnmlab ";
put @5 "14." @10 "macro " @21 "qdeduplistx ";
put @5 "15." @10 "macro " @21 "qgetvars ";
put @5 "16." @10 "macro " @21 "qzipevalf ";
put @5 "17." @10 "macro " @21 "raincloudplot ";
put @5 "18." @10 "macro " @21 "repeattxt ";
put @5 "19." @10 "macro " @21 "splitdsintoblocks ";
put @5 "20." @10 "macro " @21 "splitdsintoparts ";
put @5 "21." @10 "macro " @21 "symdelglobal ";
put @5 "22." @10 "macro " @21 "unziparch ";
put @5 "23." @10 "macro " @21 "unziplibrary ";
put @5 "24." @10 "macro " @21 "ziparch ";
put @5 "25." @10 "macro " @21 "zipevalf ";
put @5 "26." @10 "macro " @21 "ziplibrary ";
put @5 "27." @10 "format " @21 "bool ";
put @5 "28." @10 "format " @21 "boolz ";
put @5 "29." @10 "format " @21 "ceil ";
put @5 "30." @10 "format " @21 "floor ";
put @5 "31." @10 "format " @21 "int ";
put @5 "32." @10 "functions " @21 "arrfill ";
put @5 "33." @10 "functions " @21 "arrfillc ";
put @5 "34." @10 "functions " @21 "arrmissfill ";
put @5 "35." @10 "functions " @21 "arrmissfillc ";
put @5 "36." @10 "functions " @21 "arrmisstoleft ";
put @5 "37." @10 "functions " @21 "arrmisstoleftc ";
put @5 "38." @10 "functions " @21 "arrmisstoright ";
put @5 "39." @10 "functions " @21 "arrmisstorightc ";
put @5 "40." @10 "functions " @21 "bracketsc ";
put @5 "41." @10 "functions " @21 "bracketsn ";
put @5 "42." @10 "functions " @21 "catxfc ";
put @5 "43." @10 "functions " @21 "catxfi ";
put @5 "44." @10 "functions " @21 "catxfj ";
put @5 "45." @10 "functions " @21 "catxfn ";
put @5 "46." @10 "functions " @21 "deldataset ";
put @5 "47." @10 "functions " @21 "semicolonc ";
put @5 "48." @10 "functions " @21 "semicolonn ";
put @5 "49." @10 "formats " @21 "bpklenght ";
put @5 "50." @10 "formats " @21 "bplenght ";
put @5 "51." @10 "formats " @21 "brackets ";
put @5 "52." @10 "formats " @21 "semicolon ";
put @5 "53." @10 "proto " @21 "qsortincbyprocproto ";
put @5 "54." @10 "functions " @21 "frommissingtonumberbs ";
put @5 "55." @10 "functions " @21 "fromnumbertomissing ";
put @5 "56." @10 "functions " @21 "quicksort4notmiss ";
put @5 "57." @10 "functions " @21 "quicksorthash ";
put @5 "58." @10 "functions " @21 "quicksorthashsddv ";
put @5 "59." @10 "functions " @21 "quicksortlight ";
put @5 "60." @10 "macro " @21 "date ";
put @5 "61." @10 "macro " @21 "datetime ";
put @5 "62." @10 "macro " @21 "downloadfilesto ";
put @5 "63." @10 "macro " @21 "expanddatasetslist ";
put @5 "64." @10 "macro " @21 "filepath ";
put @5 "65." @10 "macro " @21 "finddswithvarval ";
put @5 "66." @10 "macro " @21 "fmt ";
put @5 "67." @10 "macro " @21 "generateoneliners ";
put @5 "68." @10 "macro " @21 "gettitle ";
put @5 "69." @10 "macro " @21 "iffunc ";
put @5 "70." @10 "macro " @21 "infmt ";
put @5 "71." @10 "macro " @21 "letters ";
put @5 "72." @10 "macro " @21 "libpath ";
put @5 "73." @10 "macro " @21 "minclude ";
put @5 "74." @10 "macro " @21 "monthshift ";
put @5 "75." @10 "macro " @21 "replist ";
put @5 "76." @10 "macro " @21 "time ";
put @5 "77." @10 "macro " @21 "today ";
put @5 "78." @10 "macro " @21 "translate ";
put @5 "79." @10 "macro " @21 "tranwrd ";
put @5 "80." @10 "macro " @21 "unifyvarscasesize ";
put @5 "81." @10 "macro " @21 "worklib ";
put @5 "82." @10 "macro " @21 "workpath ";
put ;
put @3 'Package contains additional content, run:  %loadPackageAddCnt(BasePlus)  to load it';
put @3 'or look for the baseplus_AdditionalContent directory in the Packages fileref';
put @3 'localization (only if additional content was deployed during the installation process).';
put ;
put " " / @3 "---------------------------------------------------------------------" / " ";
put @3 "*SAS package generated by SAS Package Framework, version `20260515`*";
put @3 '*under `WIN`(`X64_10PRO`) operating system,*';
put @3 '*using SAS release: `9.04.01M9P06052025`.*';
put " " / @3 "---------------------------------------------------------------------";
run;                                                                      

data _null_;                                                   
  if upcase(strip(symget("helpKeyword"))) = "LICENSE" then     
    do until (EOF);                                            
      infile PC5C9E00(license.sas) end = EOF;        
      input;                                                   
      put "| " _infile_;                                       
    end;                                                       
  else stop;                                                   
run;                                                           
data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
007_macro/007/macro/bppipe.sas/bppipe/'%bppipe()'
007_macro/007/macro/deduplistc.sas/deduplistc/'%deduplistc()'
007_macro/007/macro/deduplistp.sas/deduplistp/'%deduplistp()'
007_macro/007/macro/deduplists.sas/deduplists/'%deduplists()'
007_macro/007/macro/deduplistx.sas/deduplistx/'%deduplistx()'
007_macro/007/macro/dirsandfiles.sas/dirsandfiles/'%dirsandfiles()'
007_macro/007/macro/functionexists.sas/functionexists/'%functionexists()'
007_macro/007/macro/getvars.sas/getvars/'%getvars()'
007_macro/007/macro/intslist.sas/intslist/'%intslist()'
007_macro/007/macro/ldsn.sas/ldsn/'%ldsn()'
007_macro/007/macro/ldsnm.sas/ldsnm/'%ldsnm()'
007_macro/007/macro/lvarnm.sas/lvarnm/'%lvarnm()'
007_macro/007/macro/lvarnmlab.sas/lvarnmlab/'%lvarnmlab()'
007_macro/007/macro/qdeduplistx.sas/qdeduplistx/'%qdeduplistx()'
007_macro/007/macro/qgetvars.sas/qgetvars/'%qgetvars()'
007_macro/007/macro/qzipevalf.sas/qzipevalf/'%qzipevalf()'
007_macro/007/macro/raincloudplot.sas/raincloudplot/'%raincloudplot()'
007_macro/007/macro/repeattxt.sas/repeattxt/'%repeattxt()'
007_macro/007/macro/splitdsintoblocks.sas/splitdsintoblocks/'%splitdsintoblocks()'
007_macro/007/macro/splitdsintoparts.sas/splitdsintoparts/'%splitdsintoparts()'
007_macro/007/macro/symdelglobal.sas/symdelglobal/'%symdelglobal()'
007_macro/007/macro/unziparch.sas/unziparch/'%unziparch()'
007_macro/007/macro/unziplibrary.sas/unziplibrary/'%unziplibrary()'
007_macro/007/macro/ziparch.sas/ziparch/'%ziparch()'
007_macro/007/macro/zipevalf.sas/zipevalf/'%zipevalf()'
007_macro/007/macro/ziplibrary.sas/ziplibrary/'%ziplibrary()'
008_format/008/format/bool.sas/bool/'$bool.'
008_format/008/format/boolz.sas/boolz/'$boolz.'
008_format/008/format/ceil.sas/ceil/'$ceil.'
008_format/008/format/floor.sas/floor/'$floor.'
008_format/008/format/int.sas/int/'$int.'
009_functions/009/functions/arrfill.sas/arrfill/'arrfill()'
009_functions/009/functions/arrfillc.sas/arrfillc/'arrfillc()'
009_functions/009/functions/arrmissfill.sas/arrmissfill/'arrmissfill()'
009_functions/009/functions/arrmissfillc.sas/arrmissfillc/'arrmissfillc()'
009_functions/009/functions/arrmisstoleft.sas/arrmisstoleft/'arrmisstoleft()'
009_functions/009/functions/arrmisstoleftc.sas/arrmisstoleftc/'arrmisstoleftc()'
009_functions/009/functions/arrmisstoright.sas/arrmisstoright/'arrmisstoright()'
009_functions/009/functions/arrmisstorightc.sas/arrmisstorightc/'arrmisstorightc()'
009_functions/009/functions/bracketsc.sas/bracketsc/'bracketsc()'
009_functions/009/functions/bracketsn.sas/bracketsn/'bracketsn()'
009_functions/009/functions/catxfc.sas/catxfc/'catxfc()'
009_functions/009/functions/catxfi.sas/catxfi/'catxfi()'
009_functions/009/functions/catxfj.sas/catxfj/'catxfj()'
009_functions/009/functions/catxfn.sas/catxfn/'catxfn()'
009_functions/009/functions/deldataset.sas/deldataset/'deldataset()'
009_functions/009/functions/semicolonc.sas/semicolonc/'semicolonc()'
009_functions/009/functions/semicolonn.sas/semicolonn/'semicolonn()'
010_formats/010/formats/bpklenght.sas/bpklenght/'$bpklenght.'
010_formats/010/formats/bplenght.sas/bplenght/'$bplenght.'
010_formats/010/formats/brackets.sas/brackets/'$brackets.'
010_formats/010/formats/semicolon.sas/semicolon/'$semicolon.'
011_proto/011/proto/qsortincbyprocproto.sas/qsortincbyprocproto/'qsortincbyprocproto()'
012_functions/012/functions/frommissingtonumberbs.sas/frommissingtonumberbs/'frommissingtonumberbs()'
012_functions/012/functions/fromnumbertomissing.sas/fromnumbertomissing/'fromnumbertomissing()'
012_functions/012/functions/quicksort4notmiss.sas/quicksort4notmiss/'quicksort4notmiss()'
012_functions/012/functions/quicksorthash.sas/quicksorthash/'quicksorthash()'
012_functions/012/functions/quicksorthashsddv.sas/quicksorthashsddv/'quicksorthashsddv()'
012_functions/012/functions/quicksortlight.sas/quicksortlight/'quicksortlight()'
013_macro/013/macro/date.sas/date/'%date()'
013_macro/013/macro/datetime.sas/datetime/'%datetime()'
013_macro/013/macro/downloadfilesto.sas/downloadfilesto/'%downloadfilesto()'
013_macro/013/macro/expanddatasetslist.sas/expanddatasetslist/'%expanddatasetslist()'
013_macro/013/macro/filepath.sas/filepath/'%filepath()'
013_macro/013/macro/finddswithvarval.sas/finddswithvarval/'%finddswithvarval()'
013_macro/013/macro/fmt.sas/fmt/'%fmt()'
013_macro/013/macro/generateoneliners.sas/generateoneliners/'%generateoneliners()'
013_macro/013/macro/gettitle.sas/gettitle/'%gettitle()'
013_macro/013/macro/iffunc.sas/iffunc/'%iffunc()'
013_macro/013/macro/infmt.sas/infmt/'%infmt()'
013_macro/013/macro/letters.sas/letters/'%letters()'
013_macro/013/macro/libpath.sas/libpath/'%libpath()'
013_macro/013/macro/minclude.sas/minclude/'%minclude()'
013_macro/013/macro/monthshift.sas/monthshift/'%monthshift()'
013_macro/013/macro/replist.sas/replist/'%replist()'
013_macro/013/macro/time.sas/time/'%time()'
013_macro/013/macro/today.sas/today/'%today()'
013_macro/013/macro/translate.sas/translate/'%translate()'
013_macro/013/macro/tranwrd.sas/tranwrd/'%tranwrd()'
013_macro/013/macro/unifyvarscasesize.sas/unifyvarscasesize/'%unifyvarscasesize()'
013_macro/013/macro/worklib.sas/worklib/'%worklib()'
013_macro/013/macro/workpath.sas/workpath/'%workpath()'
;;;;
run;

data _null_;                                                                                              
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;                            
if NOBS = 0 then do; 
put; put ' *> No help info found. Try %helpPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                                        
   set WORK._last_ end = EOFDS nobs = NOBS;                                                               
   length memberX $ 1024;                                                                                 
   memberX = cats("_",folder,".",file);                                                                   
   call execute("data _null_;                                                                          ");
   call execute('infile PC5C9E00(' || strip(memberX) || ') end = EOF;                        ');
   call execute("    printer = 0;                                                                      ");
   call execute("    do until(EOF);                                                                    ");
   call execute("      input;                                                                          ");
   call execute("      _endhelpline_ = upcase(reverse(strip(_infile_)));                               ");
   call execute("      if 18 <= lengthn(_endhelpline_) AND _endhelpline_                                  
                          =: '/*** DNE PLEH ***/' then printer = 0;                                  ");
   call execute("      if printer then put ""| "" _infile_;                                            ");
   call execute("      _starthelpline_ = upcase(strip(_infile_));                                      ");
   call execute("      if 20 <= lengthn(_starthelpline_) AND _starthelpline_                              
                          =: '/*** HELP START ***/' then printer = 1;                                ");
   call execute("    end;                                                                              ");
   call execute("  put "" "" / "" "";                                                                  ");
   call execute("  stop;                                                                               ");
   call execute("run;                                                                                  ");
   if lowcase(type) in ("data" "lazydata") then                                                           
    do;                                                                                                   
     call execute("title ""Dataset " || strip(fileshort) || " from package &packageName. "";           ");
     if exist(fileshort) then call execute("proc contents data = " || strip(fileshort) || "; run;      ");
     else call execute("data _null_; put ""| Dataset " || strip(fileshort) || " does not exist.""; run;");
     call execute("title;                                                                              ");
    end;                                                                                                  
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
data &packageContentDS. _NULL_;                        
 if "&packageContentDS." = " " then stop;              
  infile cards4 dlm = "/";                             
  input (folder order type file fileshort) (: $ 256.); 
  output;                                              
cards4;                                                
007_macro/007/macro/bppipe.sas/bppipe
007_macro/007/macro/deduplistc.sas/deduplistc
007_macro/007/macro/deduplistp.sas/deduplistp
007_macro/007/macro/deduplists.sas/deduplists
007_macro/007/macro/deduplistx.sas/deduplistx
007_macro/007/macro/dirsandfiles.sas/dirsandfiles
007_macro/007/macro/functionexists.sas/functionexists
007_macro/007/macro/getvars.sas/getvars
007_macro/007/macro/intslist.sas/intslist
007_macro/007/macro/ldsn.sas/ldsn
007_macro/007/macro/ldsnm.sas/ldsnm
007_macro/007/macro/lvarnm.sas/lvarnm
007_macro/007/macro/lvarnmlab.sas/lvarnmlab
007_macro/007/macro/qdeduplistx.sas/qdeduplistx
007_macro/007/macro/qgetvars.sas/qgetvars
007_macro/007/macro/qzipevalf.sas/qzipevalf
007_macro/007/macro/raincloudplot.sas/raincloudplot
007_macro/007/macro/repeattxt.sas/repeattxt
007_macro/007/macro/splitdsintoblocks.sas/splitdsintoblocks
007_macro/007/macro/splitdsintoparts.sas/splitdsintoparts
007_macro/007/macro/symdelglobal.sas/symdelglobal
007_macro/007/macro/unziparch.sas/unziparch
007_macro/007/macro/unziplibrary.sas/unziplibrary
007_macro/007/macro/ziparch.sas/ziparch
007_macro/007/macro/zipevalf.sas/zipevalf
007_macro/007/macro/ziplibrary.sas/ziplibrary
008_format/008/format/bool.sas/bool
008_format/008/format/boolz.sas/boolz
008_format/008/format/ceil.sas/ceil
008_format/008/format/floor.sas/floor
008_format/008/format/int.sas/int
009_functions/009/functions/arrfill.sas/arrfill
009_functions/009/functions/arrfillc.sas/arrfillc
009_functions/009/functions/arrmissfill.sas/arrmissfill
009_functions/009/functions/arrmissfillc.sas/arrmissfillc
009_functions/009/functions/arrmisstoleft.sas/arrmisstoleft
009_functions/009/functions/arrmisstoleftc.sas/arrmisstoleftc
009_functions/009/functions/arrmisstoright.sas/arrmisstoright
009_functions/009/functions/arrmisstorightc.sas/arrmisstorightc
009_functions/009/functions/bracketsc.sas/bracketsc
009_functions/009/functions/bracketsn.sas/bracketsn
009_functions/009/functions/catxfc.sas/catxfc
009_functions/009/functions/catxfi.sas/catxfi
009_functions/009/functions/catxfj.sas/catxfj
009_functions/009/functions/catxfn.sas/catxfn
009_functions/009/functions/deldataset.sas/deldataset
009_functions/009/functions/semicolonc.sas/semicolonc
009_functions/009/functions/semicolonn.sas/semicolonn
010_formats/010/formats/bpklenght.sas/bpklenght
010_formats/010/formats/bplenght.sas/bplenght
010_formats/010/formats/brackets.sas/brackets
010_formats/010/formats/semicolon.sas/semicolon
011_proto/011/proto/qsortincbyprocproto.sas/qsortincbyprocproto
012_functions/012/functions/frommissingtonumberbs.sas/frommissingtonumberbs
012_functions/012/functions/fromnumbertomissing.sas/fromnumbertomissing
012_functions/012/functions/quicksort4notmiss.sas/quicksort4notmiss
012_functions/012/functions/quicksorthash.sas/quicksorthash
012_functions/012/functions/quicksorthashsddv.sas/quicksorthashsddv
012_functions/012/functions/quicksortlight.sas/quicksortlight
013_macro/013/macro/date.sas/date
013_macro/013/macro/datetime.sas/datetime
013_macro/013/macro/downloadfilesto.sas/downloadfilesto
013_macro/013/macro/expanddatasetslist.sas/expanddatasetslist
013_macro/013/macro/filepath.sas/filepath
013_macro/013/macro/finddswithvarval.sas/finddswithvarval
013_macro/013/macro/fmt.sas/fmt
013_macro/013/macro/generateoneliners.sas/generateoneliners
013_macro/013/macro/gettitle.sas/gettitle
013_macro/013/macro/iffunc.sas/iffunc
013_macro/013/macro/infmt.sas/infmt
013_macro/013/macro/letters.sas/letters
013_macro/013/macro/libpath.sas/libpath
013_macro/013/macro/minclude.sas/minclude
013_macro/013/macro/monthshift.sas/monthshift
013_macro/013/macro/replist.sas/replist
013_macro/013/macro/time.sas/time
013_macro/013/macro/today.sas/today
013_macro/013/macro/translate.sas/translate
013_macro/013/macro/tranwrd.sas/tranwrd
013_macro/013/macro/unifyvarscasesize.sas/unifyvarscasesize
013_macro/013/macro/worklib.sas/worklib
013_macro/013/macro/workpath.sas/workpath
;;;;
run;
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 
%put NOTE: Help for package BasePlus, version 3.2.0, license MIT;
%put NOTE- *** END ***;
/* help.sas end */
