filename PC5C9E00 list;
 %put NOTE- ;
 %put NOTE: Data for package BasePlus, version 3.2.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-28T12:00:14; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(BasePlus) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package BasePlus, version 3.2.0, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
