/*** HELP START ***//*

## >>> `%workLib()` macro: <<< <a name="worklib-macro"></a> ####################### 

The `%workLib()` macro creates and assigns a WORK-scoped sub-library.

Purpose:

The macro creates (if needed) and assigns a SAS library as a sub-directory 
under the current `WORK` location. This is useful for isolating temporary 
outputs per task while ensuring automatic cleanup at the end of the SAS session.
Basic engines libraries, like `BASE`, `V*`, and simple `SPDE`, can be set.

### SYNTAX: ###################################################################

The basic syntax is the following, the `<...>` means optional parameters:
~~~~~~~~~~~~~~~~~~~~~~~sas
%workLib(lib,<engine>)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:
 
- `lib`    - *Required*: Name of a library (and sub-folder) 
             to create under WORK. The value must be a valid 
             nonempty SAS libref (8 characters max, starting 
             with a letter or underscore).

- `engine` - *Optional*, Name of a basic, directory level, 
             SAS engine, e.g. `BASE`. When empty the default
             engine is used.
---

### Details  

- Builds a target path: `<WORK>/<lib>`.
- All data written to this libref are temporary and will be removed 
  when the WORK library is cleared at session end.
- If a directory with the same name already exists under WORK, 
  the macro prints a note and simply assigns the LIBNAME to 
  that location.
- The `dcreate()` function is used to create sub-directory.

*//*** HELP END ***/

%macro workLib(lib, engine);
%if %superq(lib)= %then
  %do;
    %put WARNING:[&sysmacroname.] The LIB parameter cannot be empty!;
  %end;
%else
  %do;
    %if 0=%sysfunc(NVALID(%superq(lib),V7)) %then
      %do;
        %put WARNING:[&sysmacroname.] The LIB parameter contains incorrect symbols!; 
        %put WARNING-[&sysmacroname.] &=LIB.;
      %end;
    %else
      %do;
        /* select only first 8 characters */
        %let lib = %upcase(%substr(%sysfunc(compress(%superq(lib),_,kad))       #,1,8));
        /*%put &=lib.;*/
        %local workpath rc;
        %let workpath = %sysfunc(getoption(work));

        /* Create directory if one does not exist */
        %if %sysfunc(fileexist(&workpath./&lib.)) = 0 %then
          %let rc = %sysfunc(dcreate(&lib.,&workpath.));
        %else 
          %put NOTE:[&sysmacroname.] Directory &lib. already exists inside the WORK directory.;

        %if %sysfunc(fileexist(&workpath./&lib.)) = 1 %then
          %do;
            /* Assign library and list it */
            libname &lib. &engine. "&workpath./&lib.";
            libname &lib. list;
          %end;
        %else 
          %put ERROR:[&sysmacroname.] Directory &lib. does NOT exist inside the WORK directory.;
      %end;
  %end;
%mend workLib;

/* test cases 
%workLib()

%workLib(a$b$c)
*/



/*** HELP START ***//*
 
### EXAMPLES AND USECASES: ####################################################

**EXAMPLE 1.** Create library ABC assigned to `<WORK>/ABC` directory:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
  %workLib(abc)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 2.** Create libraries with different engines:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
  %workLib(b,BASE)

  %workLib(v,V6) %* for Windows only.;

  %workLib(s,SPDE)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---

*//*** HELP END ***/

/**###################################################################**/
/*                                                                     */
/*  Copyright Ryo Nakaya, Bartosz Jablonski, since 2025.               */
/*                                                                     */
/*  Code is under the MIT license. If you want - you can use it.       */
/*  But it comes with absolutely no warranty whatsoever.               */
/*  If you cause any damage or something - it will be your own fault.  */
/*  You've been warned! You are using it on your own risk.             */
/*  However, if you decide to use it don't forget to mention authors.  */
/*  Ryo Nakaya (nakaya.ryou@gmail.com)                                 */
/*  Bartosz Jablonski (yabwon@gmail.com)                               */
/*                                                                     */
/**###################################################################**/
