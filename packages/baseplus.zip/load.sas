filename PC5C9E00 list;

 %put NOTE- ;
 %put NOTE: Loading package BasePlus, version 3.1.5, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-12T16:34:34; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(BasePlus) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  PC5C9E00(packagemetadata.sas) / nosource2; 

 
%if (%str(*)=%superq(cherryPick)) or (bppipe in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "bppipe.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(bppipe)=1, NOTE# Macro bppipe exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.bppipe.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (deduplistc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "deduplistc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(deduplistc)=1, NOTE# Macro deduplistc exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.deduplistc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (deduplistp in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "deduplistp.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(deduplistp)=1, NOTE# Macro deduplistp exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.deduplistp.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (deduplists in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "deduplists.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(deduplists)=1, NOTE# Macro deduplists exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.deduplists.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (deduplistx in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "deduplistx.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(deduplistx)=1, NOTE# Macro deduplistx exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.deduplistx.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (dirsandfiles in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "dirsandfiles.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(dirsandfiles)=1, NOTE# Macro dirsandfiles exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.dirsandfiles.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (functionexists in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "functionexists.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(functionexists)=1, NOTE# Macro functionexists exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.functionexists.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (getvars in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "getvars.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(getvars)=1, NOTE# Macro getvars exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.getvars.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (intslist in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "intslist.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(intslist)=1, NOTE# Macro intslist exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.intslist.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ldsn in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "ldsn.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ldsn)=1, NOTE# Macro ldsn exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.ldsn.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ldsnm in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "ldsnm.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ldsnm)=1, NOTE# Macro ldsnm exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.ldsnm.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (lvarnm in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "lvarnm.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(lvarnm)=1, NOTE# Macro lvarnm exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.lvarnm.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (lvarnmlab in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "lvarnmlab.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(lvarnmlab)=1, NOTE# Macro lvarnmlab exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.lvarnmlab.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (qdeduplistx in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "qdeduplistx.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(qdeduplistx)=1, NOTE# Macro qdeduplistx exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.qdeduplistx.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (qgetvars in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "qgetvars.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(qgetvars)=1, NOTE# Macro qgetvars exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.qgetvars.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (qzipevalf in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "qzipevalf.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(qzipevalf)=1, NOTE# Macro qzipevalf exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.qzipevalf.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (raincloudplot in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "raincloudplot.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(raincloudplot)=1, NOTE# Macro raincloudplot exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.raincloudplot.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (repeattxt in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "repeattxt.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(repeattxt)=1, NOTE# Macro repeattxt exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.repeattxt.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (splitdsintoblocks in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "splitdsintoblocks.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(splitdsintoblocks)=1, NOTE# Macro splitdsintoblocks exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.splitdsintoblocks.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (splitdsintoparts in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "splitdsintoparts.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(splitdsintoparts)=1, NOTE# Macro splitdsintoparts exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.splitdsintoparts.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (symdelglobal in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "symdelglobal.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(symdelglobal)=1, NOTE# Macro symdelglobal exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.symdelglobal.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (unziparch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "unziparch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(unziparch)=1, NOTE# Macro unziparch exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.unziparch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (unziplibrary in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "unziplibrary.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(unziplibrary)=1, NOTE# Macro unziplibrary exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.unziplibrary.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ziparch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "ziparch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ziparch)=1, NOTE# Macro ziparch exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.ziparch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (zipevalf in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "zipevalf.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(zipevalf)=1, NOTE# Macro zipevalf exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.zipevalf.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ziplibrary in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "ziplibrary.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(ziplibrary)=1, NOTE# Macro ziplibrary exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_007_macro.ziplibrary.sas) / nosource2;
%end; 

data _null_; 
  call symputX('cherryPick_FORMAT', cexist('work.BasePlusformat'), 'L'); 
run; 
 
%if (%str(*)=%superq(cherryPick)) or (bool in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type format from the file "bool.sas" will be included <<;
  %include PC5C9E00(_008_format.bool.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(fmtsearch)))
                ,work.baseplusformat,"'( )'",RIO))
,,%str(options INSERT=(fmtsearch = work.baseplusformat);)
))
 
%if (%str(*)=%superq(cherryPick)) or (boolz in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type format from the file "boolz.sas" will be included <<;
  %include PC5C9E00(_008_format.boolz.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (ceil in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type format from the file "ceil.sas" will be included <<;
  %include PC5C9E00(_008_format.ceil.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (floor in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type format from the file "floor.sas" will be included <<;
  %include PC5C9E00(_008_format.floor.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (int in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type format from the file "int.sas" will be included <<;
  %include PC5C9E00(_008_format.int.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

data _null_; 
  call symputX('cherryPick_FCMP', exist('work.BasePlusfcmp'), 'L'); 
run; 
proc fcmp outlib = work.BasePlusfcmp.package ; 
 
%if (%str(*)=%superq(cherryPick)) or (arrfill in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrfill.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrfill.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.baseplusfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.baseplusfcmp);)
))
 
%if (%str(*)=%superq(cherryPick)) or (arrfillc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrfillc.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrfillc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (arrmissfill in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrmissfill.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrmissfill.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (arrmissfillc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrmissfillc.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrmissfillc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (arrmisstoleft in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrmisstoleft.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrmisstoleft.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (arrmisstoleftc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrmisstoleftc.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrmisstoleftc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (arrmisstoright in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrmisstoright.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrmisstoright.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (arrmisstorightc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "arrmisstorightc.sas" will be included <<;
  %include PC5C9E00(_009_functions.arrmisstorightc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (bracketsc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "bracketsc.sas" will be included <<;
  %include PC5C9E00(_009_functions.bracketsc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (bracketsn in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "bracketsn.sas" will be included <<;
  %include PC5C9E00(_009_functions.bracketsn.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (catxfc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "catxfc.sas" will be included <<;
  %include PC5C9E00(_009_functions.catxfc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (catxfi in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "catxfi.sas" will be included <<;
  %include PC5C9E00(_009_functions.catxfi.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (catxfj in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "catxfj.sas" will be included <<;
  %include PC5C9E00(_009_functions.catxfj.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (catxfn in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "catxfn.sas" will be included <<;
  %include PC5C9E00(_009_functions.catxfn.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (deldataset in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "deldataset.sas" will be included <<;
  %include PC5C9E00(_009_functions.deldataset.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (semicolonc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "semicolonc.sas" will be included <<;
  %include PC5C9E00(_009_functions.semicolonc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (semicolonn in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "semicolonn.sas" will be included <<;
  %include PC5C9E00(_009_functions.semicolonn.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

quit; 

proc format lib = work.BasePlusformat ; 
 
%if (%str(*)=%superq(cherryPick)) or (bpklenght in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type formats from the file "bpklenght.sas" will be included <<;
  %include PC5C9E00(_010_formats.bpklenght.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(fmtsearch)))
                ,work.baseplusformat,"'( )'",RIO))
,,%str(options INSERT=(fmtsearch = work.baseplusformat);)
))
 
%if (%str(*)=%superq(cherryPick)) or (bplenght in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type formats from the file "bplenght.sas" will be included <<;
  %include PC5C9E00(_010_formats.bplenght.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (brackets in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type formats from the file "brackets.sas" will be included <<;
  %include PC5C9E00(_010_formats.brackets.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (semicolon in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type formats from the file "semicolon.sas" will be included <<;
  %include PC5C9E00(_010_formats.semicolon.sas) / nosource2;
  %let cherryPick_FORMAT = %eval(&cherryPick_FORMAT. + 1);
%end; 

quit; 

data _null_; 
  call symputX('cherryPick_PROTO', exist('work.BasePlusproto'), 'L'); 
run; 
proc proto package = work.BasePlusproto.package1
 LABEL='Proc Proto C functions for BasePlus package, part1 ' ; 
 
%if (%str(*)=%superq(cherryPick)) or (qsortincbyprocproto in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type proto from the file "qsortincbyprocproto.sas" will be included <<;
  %include PC5C9E00(_011_proto.qsortincbyprocproto.sas) / nosource2;
  %let cherryPick_PROTO = %eval(&cherryPick_PROTO. + 1);
%end; 

quit; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.baseplusproto,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.baseplusproto);)
))
proc fcmp outlib = work.BasePlusfcmp.package ; 
 
%if (%str(*)=%superq(cherryPick)) or (frommissingtonumberbs in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "frommissingtonumberbs.sas" will be included <<;
  %include PC5C9E00(_012_functions.frommissingtonumberbs.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.baseplusfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.baseplusfcmp);)
))
 
%if (%str(*)=%superq(cherryPick)) or (fromnumbertomissing in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "fromnumbertomissing.sas" will be included <<;
  %include PC5C9E00(_012_functions.fromnumbertomissing.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (quicksort4notmiss in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "quicksort4notmiss.sas" will be included <<;
  %include PC5C9E00(_012_functions.quicksort4notmiss.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (quicksorthash in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "quicksorthash.sas" will be included <<;
  %include PC5C9E00(_012_functions.quicksorthash.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (quicksorthashsddv in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "quicksorthashsddv.sas" will be included <<;
  %include PC5C9E00(_012_functions.quicksorthashsddv.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (quicksortlight in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type functions from the file "quicksortlight.sas" will be included <<;
  %include PC5C9E00(_012_functions.quicksortlight.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

quit; 

 
%if (%str(*)=%superq(cherryPick)) or (date in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "date.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(date)=1, NOTE# Macro date exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.date.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (datetime in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "datetime.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(datetime)=1, NOTE# Macro datetime exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.datetime.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (downloadfilesto in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "downloadfilesto.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(downloadfilesto)=1, NOTE# Macro downloadfilesto exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.downloadfilesto.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (expanddatasetslist in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "expanddatasetslist.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(expanddatasetslist)=1, NOTE# Macro expanddatasetslist exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.expanddatasetslist.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (filepath in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "filepath.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(filepath)=1, NOTE# Macro filepath exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.filepath.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (finddswithvarval in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "finddswithvarval.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(finddswithvarval)=1, NOTE# Macro finddswithvarval exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.finddswithvarval.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (fmt in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "fmt.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(fmt)=1, NOTE# Macro fmt exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.fmt.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (generateoneliners in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "generateoneliners.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(generateoneliners)=1, NOTE# Macro generateoneliners exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.generateoneliners.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (gettitle in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "gettitle.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(gettitle)=1, NOTE# Macro gettitle exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.gettitle.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (iffunc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "iffunc.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(iffunc)=1, NOTE# Macro iffunc exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.iffunc.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (infmt in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "infmt.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(infmt)=1, NOTE# Macro infmt exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.infmt.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (letters in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "letters.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(letters)=1, NOTE# Macro letters exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.letters.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (libpath in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "libpath.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(libpath)=1, NOTE# Macro libpath exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.libpath.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (minclude in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "minclude.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(minclude)=1, NOTE# Macro minclude exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.minclude.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (monthshift in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "monthshift.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(monthshift)=1, NOTE# Macro monthshift exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.monthshift.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (replist in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "replist.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(replist)=1, NOTE# Macro replist exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.replist.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (time in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "time.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(time)=1, NOTE# Macro time exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.time.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (today in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "today.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(today)=1, NOTE# Macro today exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.today.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (translate in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "translate.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(translate)=1, NOTE# Macro translate exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.translate.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (tranwrd in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "tranwrd.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(tranwrd)=1, NOTE# Macro tranwrd exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.tranwrd.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (unifyvarscasesize in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "unifyvarscasesize.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(unifyvarscasesize)=1, NOTE# Macro unifyvarscasesize exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.unifyvarscasesize.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (worklib in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "worklib.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(worklib)=1, NOTE# Macro worklib exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.worklib.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (workpath in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "workpath.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(workpath)=1, NOTE# Macro workpath exist. It will be overwritten by the macro from the BasePlus package, ));
  %include PC5C9E00(_013_macro.workpath.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro BasePlusCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for BasePlus package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `BasePlusCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260411.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename PC5C9E00 &ZIP. '&path./baseplus.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename PC5C9E00 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

%if 0 = &cherryPick_FCMP. %then %do;
options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.baseplusfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%end;
%if 0 = &cherryPick_PROTO. %then %do;
options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.baseplusproto), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
proc delete data=work.BasePlusproto; run;
%end;
%if 0 = &cherryPick_FORMAT. %then %do;
options fmtsearch = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(fmtsearch))))
,%str(work.baseplusformat), %str() ))));
options fmtsearch = (%unquote(%sysfunc(compress(
%sysfunc(getoption(fmtsearch))
, %str(()) ))));
%end;
%put NOTE- ;
data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.BasePlusfcmp.packagemeta ; 
 function BasePlusMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("3.1.5"));
   if m = 'D' then return(strip("2026-05-12T16:34:34"));
   if m = 'A' then return(strip("Bartosz Jablonski (yabwon@gmail.com), contributors are Quentin McMullen (qmcmullen@gmail.com) and Ryo Nakaya (nakaya.ryou@gmail.com)"));
   if m = 'M' then return(strip("Bartosz Jablonski (yabwon@gmail.com)"));
   if m = 'T' then return(strip("The BASE SAS plus a bunch of functionalities I am missing in BASE SAS"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-05-12T16:34:34"));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.baseplusfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.baseplusfcmp);)
))
%macro BasePlusMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(BasePlusMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%put NOTE- ;
%put NOTE:[FMTSEARCH] %sysfunc(getoption(fmtsearch));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#baseplus(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'BasePlus(3.1.5)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'BasePlus(3.1.5)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'BasePlus(3.1.5)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] BasePlus(3.1.5)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package BasePlus, version 3.1.5, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

