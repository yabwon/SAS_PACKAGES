/*** HELP START ***//*
 
## >>> `semicolonC()` function: <<< <a name="semicolonc-function"></a> #######################  

The **semicolonC()** function is internal function used by the *semicolon* format.
Returns character value of length 32767.
 
### SYNTAX: ###################################################################

The basic syntax is the following:
~~~~~~~~~~~~~~~~~~~~~~~sas
semicolonC(X)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `X` - Character value.

---

*//*** HELP END ***/

  function semicolonC(x $) $ 32767;
    return ( cats(x, ";") );
  endsub;

