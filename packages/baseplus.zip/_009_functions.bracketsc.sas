/*** HELP START ***//*
 
## >>> `bracketsC()` function: <<< <a name="bracketsc-function"></a> #######################  

The **bracketsC()** function is internal function used by the *brackets* format.
Returns character value of length 32767.
 
### SYNTAX: ###################################################################

The basic syntax is the following:
~~~~~~~~~~~~~~~~~~~~~~~sas
bracketsC(X)
~~~~~~~~~~~~~~~~~~~~~~~

**Arguments description**:

1. `X` - Character value.

---
*//*** HELP END ***/

  function bracketsC(x $) $ 32767;
    return ( cats("(", x, ")") );
  endsub;

