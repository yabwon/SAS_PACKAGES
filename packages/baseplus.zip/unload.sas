filename PC5C9E00 list;
%put NOTE: Unloading package BasePlus, version 3.1.5, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'BASEPLUSMETA'
   ,'BASEPLUSIML'
   ,'BASEPLUSCASLUDF'
   %put NOTE- Element of type macro generated from the file "bppipe.sas" will be deleted;
   %put NOTE- ;
   ,"BPPIPE                                                          "
   %put NOTE- Element of type macro generated from the file "deduplistc.sas" will be deleted;
   %put NOTE- ;
   ,"DEDUPLISTC                                                      "
   %put NOTE- Element of type macro generated from the file "deduplistp.sas" will be deleted;
   %put NOTE- ;
   ,"DEDUPLISTP                                                      "
   %put NOTE- Element of type macro generated from the file "deduplists.sas" will be deleted;
   %put NOTE- ;
   ,"DEDUPLISTS                                                      "
   %put NOTE- Element of type macro generated from the file "deduplistx.sas" will be deleted;
   %put NOTE- ;
   ,"DEDUPLISTX                                                      "
   %put NOTE- Element of type macro generated from the file "dirsandfiles.sas" will be deleted;
   %put NOTE- ;
   ,"DIRSANDFILES                                                    "
   %put NOTE- Element of type macro generated from the file "functionexists.sas" will be deleted;
   %put NOTE- ;
   ,"FUNCTIONEXISTS                                                  "
   %put NOTE- Element of type macro generated from the file "getvars.sas" will be deleted;
   %put NOTE- ;
   ,"GETVARS                                                         "
   %put NOTE- Element of type macro generated from the file "intslist.sas" will be deleted;
   %put NOTE- ;
   ,"INTSLIST                                                        "
   %put NOTE- Element of type macro generated from the file "ldsn.sas" will be deleted;
   %put NOTE- ;
   ,"LDSN                                                            "
   %put NOTE- Element of type macro generated from the file "ldsnm.sas" will be deleted;
   %put NOTE- ;
   ,"LDSNM                                                           "
   %put NOTE- Element of type macro generated from the file "lvarnm.sas" will be deleted;
   %put NOTE- ;
   ,"LVARNM                                                          "
   %put NOTE- Element of type macro generated from the file "lvarnmlab.sas" will be deleted;
   %put NOTE- ;
   ,"LVARNMLAB                                                       "
   %put NOTE- Element of type macro generated from the file "qdeduplistx.sas" will be deleted;
   %put NOTE- ;
   ,"QDEDUPLISTX                                                     "
   %put NOTE- Element of type macro generated from the file "qgetvars.sas" will be deleted;
   %put NOTE- ;
   ,"QGETVARS                                                        "
   %put NOTE- Element of type macro generated from the file "qzipevalf.sas" will be deleted;
   %put NOTE- ;
   ,"QZIPEVALF                                                       "
   %put NOTE- Element of type macro generated from the file "raincloudplot.sas" will be deleted;
   %put NOTE- ;
   ,"RAINCLOUDPLOT                                                   "
   %put NOTE- Element of type macro generated from the file "repeattxt.sas" will be deleted;
   %put NOTE- ;
   ,"REPEATTXT                                                       "
   %put NOTE- Element of type macro generated from the file "splitdsintoblocks.sas" will be deleted;
   %put NOTE- ;
   ,"SPLITDSINTOBLOCKS                                               "
   %put NOTE- Element of type macro generated from the file "splitdsintoparts.sas" will be deleted;
   %put NOTE- ;
   ,"SPLITDSINTOPARTS                                                "
   %put NOTE- Element of type macro generated from the file "symdelglobal.sas" will be deleted;
   %put NOTE- ;
   ,"SYMDELGLOBAL                                                    "
   %put NOTE- Element of type macro generated from the file "unziparch.sas" will be deleted;
   %put NOTE- ;
   ,"UNZIPARCH                                                       "
   %put NOTE- Element of type macro generated from the file "unziplibrary.sas" will be deleted;
   %put NOTE- ;
   ,"UNZIPLIBRARY                                                    "
   %put NOTE- Element of type macro generated from the file "ziparch.sas" will be deleted;
   %put NOTE- ;
   ,"ZIPARCH                                                         "
   %put NOTE- Element of type macro generated from the file "zipevalf.sas" will be deleted;
   %put NOTE- ;
   ,"ZIPEVALF                                                        "
   %put NOTE- Element of type macro generated from the file "ziplibrary.sas" will be deleted;
   %put NOTE- ;
   ,"ZIPLIBRARY                                                      "
   %put NOTE- Element of type macro generated from the file "date.sas" will be deleted;
   %put NOTE- ;
   ,"DATE                                                            "
   %put NOTE- Element of type macro generated from the file "datetime.sas" will be deleted;
   %put NOTE- ;
   ,"DATETIME                                                        "
   %put NOTE- Element of type macro generated from the file "downloadfilesto.sas" will be deleted;
   %put NOTE- ;
   ,"DOWNLOADFILESTO                                                 "
   %put NOTE- Element of type macro generated from the file "expanddatasetslist.sas" will be deleted;
   %put NOTE- ;
   ,"EXPANDDATASETSLIST                                              "
   %put NOTE- Element of type macro generated from the file "filepath.sas" will be deleted;
   %put NOTE- ;
   ,"FILEPATH                                                        "
   %put NOTE- Element of type macro generated from the file "finddswithvarval.sas" will be deleted;
   %put NOTE- ;
   ,"FINDDSWITHVARVAL                                                "
   %put NOTE- Element of type macro generated from the file "fmt.sas" will be deleted;
   %put NOTE- ;
   ,"FMT                                                             "
   %put NOTE- Element of type macro generated from the file "generateoneliners.sas" will be deleted;
   %put NOTE- ;
   ,"GENERATEONELINERS                                               "
   %put NOTE- Element of type macro generated from the file "gettitle.sas" will be deleted;
   %put NOTE- ;
   ,"GETTITLE                                                        "
   %put NOTE- Element of type macro generated from the file "iffunc.sas" will be deleted;
   %put NOTE- ;
   ,"IFFUNC                                                          "
   %put NOTE- Element of type macro generated from the file "infmt.sas" will be deleted;
   %put NOTE- ;
   ,"INFMT                                                           "
   %put NOTE- Element of type macro generated from the file "letters.sas" will be deleted;
   %put NOTE- ;
   ,"LETTERS                                                         "
   %put NOTE- Element of type macro generated from the file "libpath.sas" will be deleted;
   %put NOTE- ;
   ,"LIBPATH                                                         "
   %put NOTE- Element of type macro generated from the file "minclude.sas" will be deleted;
   %put NOTE- ;
   ,"MINCLUDE                                                        "
   %put NOTE- Element of type macro generated from the file "monthshift.sas" will be deleted;
   %put NOTE- ;
   ,"MONTHSHIFT                                                      "
   %put NOTE- Element of type macro generated from the file "replist.sas" will be deleted;
   %put NOTE- ;
   ,"REPLIST                                                         "
   %put NOTE- Element of type macro generated from the file "time.sas" will be deleted;
   %put NOTE- ;
   ,"TIME                                                            "
   %put NOTE- Element of type macro generated from the file "today.sas" will be deleted;
   %put NOTE- ;
   ,"TODAY                                                           "
   %put NOTE- Element of type macro generated from the file "translate.sas" will be deleted;
   %put NOTE- ;
   ,"TRANSLATE                                                       "
   %put NOTE- Element of type macro generated from the file "tranwrd.sas" will be deleted;
   %put NOTE- ;
   ,"TRANWRD                                                         "
   %put NOTE- Element of type macro generated from the file "unifyvarscasesize.sas" will be deleted;
   %put NOTE- ;
   ,"UNIFYVARSCASESIZE                                               "
   %put NOTE- Element of type macro generated from the file "worklib.sas" will be deleted;
   %put NOTE- ;
   ,"WORKLIB                                                         "
   %put NOTE- Element of type macro generated from the file "workpath.sas" will be deleted;
   %put NOTE- ;
   ,"WORKPATH                                                        "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
   %put NOTE- Element of type format generated from the file "bool.sas" will be deleted;
   %put NOTE- ;
   ,"BOOL                                                            "
   %put NOTE- Element of type format generated from the file "boolz.sas" will be deleted;
   %put NOTE- ;
   ,"BOOLZ                                                           "
   %put NOTE- Element of type format generated from the file "ceil.sas" will be deleted;
   %put NOTE- ;
   ,"CEIL                                                            "
   %put NOTE- Element of type format generated from the file "floor.sas" will be deleted;
   %put NOTE- ;
   ,"FLOOR                                                           "
   %put NOTE- Element of type format generated from the file "int.sas" will be deleted;
   %put NOTE- ;
   ,"INT                                                             "
   %put NOTE- Element of type formats generated from the file "bpklenght.sas" will be deleted;
   %put NOTE- ;
   ,"BPKLENGHT                                                       "
   %put NOTE- Element of type formats generated from the file "bplenght.sas" will be deleted;
   %put NOTE- ;
   ,"BPLENGHT                                                        "
   %put NOTE- Element of type formats generated from the file "brackets.sas" will be deleted;
   %put NOTE- ;
   ,"BRACKETS                                                        "
   %put NOTE- Element of type formats generated from the file "semicolon.sas" will be deleted;
   %put NOTE- ;
   ,"SEMICOLON                                                       "
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'BASEPLUSFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc delete data = work.BasePlusformat(mtype = catalog);
run;
options fmtsearch = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(fmtsearch))))
,%str(work.baseplusformat), %str() ))));
options fmtsearch = (%unquote(%sysfunc(compress(
%sysfunc(getoption(fmtsearch))
, %str(()) ))));
%put NOTE:[FMTSEARCH] %sysfunc(getoption(fmtsearch));
%put NOTE- Element of type proto generated from the file "qsortincbyprocproto.sas" will be deleted;
%put NOTE- ;

proc delete data = work.BasePlusproto;
run;
options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.baseplusproto), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc fcmp outlib = work.BasePlusfcmp.package;
%put NOTE- Element of type functions generated from the file "arrfill.sas" will be deleted;
%put NOTE- ;
deletefunc arrfill ;
%put NOTE- Element of type functions generated from the file "arrfillc.sas" will be deleted;
%put NOTE- ;
deletefunc arrfillc ;
%put NOTE- Element of type functions generated from the file "arrmissfill.sas" will be deleted;
%put NOTE- ;
deletefunc arrmissfill ;
%put NOTE- Element of type functions generated from the file "arrmissfillc.sas" will be deleted;
%put NOTE- ;
deletefunc arrmissfillc ;
%put NOTE- Element of type functions generated from the file "arrmisstoleft.sas" will be deleted;
%put NOTE- ;
deletefunc arrmisstoleft ;
%put NOTE- Element of type functions generated from the file "arrmisstoleftc.sas" will be deleted;
%put NOTE- ;
deletefunc arrmisstoleftc ;
%put NOTE- Element of type functions generated from the file "arrmisstoright.sas" will be deleted;
%put NOTE- ;
deletefunc arrmisstoright ;
%put NOTE- Element of type functions generated from the file "arrmisstorightc.sas" will be deleted;
%put NOTE- ;
deletefunc arrmisstorightc ;
%put NOTE- Element of type functions generated from the file "bracketsc.sas" will be deleted;
%put NOTE- ;
deletefunc bracketsc ;
%put NOTE- Element of type functions generated from the file "bracketsn.sas" will be deleted;
%put NOTE- ;
deletefunc bracketsn ;
%put NOTE- Element of type functions generated from the file "catxfc.sas" will be deleted;
%put NOTE- ;
deletefunc catxfc ;
%put NOTE- Element of type functions generated from the file "catxfi.sas" will be deleted;
%put NOTE- ;
deletefunc catxfi ;
%put NOTE- Element of type functions generated from the file "catxfj.sas" will be deleted;
%put NOTE- ;
deletefunc catxfj ;
%put NOTE- Element of type functions generated from the file "catxfn.sas" will be deleted;
%put NOTE- ;
deletefunc catxfn ;
%put NOTE- Element of type functions generated from the file "deldataset.sas" will be deleted;
%put NOTE- ;
deletefunc deldataset ;
%put NOTE- Element of type functions generated from the file "semicolonc.sas" will be deleted;
%put NOTE- ;
deletefunc semicolonc ;
%put NOTE- Element of type functions generated from the file "semicolonn.sas" will be deleted;
%put NOTE- ;
deletefunc semicolonn ;
%put NOTE- Element of type functions generated from the file "frommissingtonumberbs.sas" will be deleted;
%put NOTE- ;
deletefunc frommissingtonumberbs ;
%put NOTE- Element of type functions generated from the file "fromnumbertomissing.sas" will be deleted;
%put NOTE- ;
deletefunc fromnumbertomissing ;
%put NOTE- Element of type functions generated from the file "quicksort4notmiss.sas" will be deleted;
%put NOTE- ;
deletefunc quicksort4notmiss ;
%put NOTE- Element of type functions generated from the file "quicksorthash.sas" will be deleted;
%put NOTE- ;
deletefunc quicksorthash ;
%put NOTE- Element of type functions generated from the file "quicksorthashsddv.sas" will be deleted;
%put NOTE- ;
deletefunc quicksorthashsddv ;
%put NOTE- Element of type functions generated from the file "quicksortlight.sas" will be deleted;
%put NOTE- ;
deletefunc quicksortlight ;
quit;

proc fcmp outlib = work.BasePlusfcmp.packagemeta;
deletefunc BasePlusMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.baseplusfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#baseplus(3.1.5)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#BasePlus(3.1.5)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package BasePlus, version 3.1.5, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
