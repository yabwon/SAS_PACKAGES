filename P948C2DF list;

 %put NOTE- ;
 %put NOTE: Loading package SQLinDS, version 2.4.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-11T14:15:07; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(SQLinDS) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  P948C2DF(packagemetadata.sas) / nosource2; 

 data _null_;                                                     
  call symputX("packageRequiredErrors", 0, "L");                  
 run;                                                             
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(
 options nonotes nosource %str(;)                            
 options ls=max ps=max locale=en_US %str(;)                  
 /* temporary redirect log */                                
 filename _stinit_ TEMP %str(;)                              
 proc printto log = _stinit_ %str(;) run %str(;)             
 /* print out setinit */                                     
 proc setinit %str(;) run %str(;)                            
 proc printto %str(;) run %str(;)                            
 options ps=min %str(;)                                      
 data _null_ %str(;)                                         
   /* loadup checklist of required SAS components */         
   if _n_ = 1 then                                           
     do %str(;)                                              
       length req $ 256 %str(;)                              
       declare hash R() %str(;)                              
       _N_ = R.defineKey("req") %str(;)                      
       _N_ = R.defineDone() %str(;)                          
       declare hiter iR("R") %str(;)                         
         do req = %bquote(
"BASE SAS SOFTWARE"
) %str(;)   
          _N_ = R.add(key:req,data:req) %str(;)              
         end %str(;)                                         
     end %str(;)                                             
                                                             
   /* read in output from proc setinit */                    
   infile _stinit_ end=eof %str(;)                           
   input %str(;)                                             
                                                             
   /* if component is in setinit remove it from checklist */ 
   if _infile_ =: "---" then                                 
     do %str(;)                                              
       req = upcase(substr(_infile_, 4, 64)) %str(;)         
       if R.find(key:req) = 0 then                           
         do %str(;)                                          
           _N_ = R.remove() %str(;)                          
         end %str(;)                                         
     end %str(;)                                             
                                                             
   /* if checklist is not null rise error */                 
   if eof and R.num_items > 0 then                           
     do %str(;)                                              
       put "WARNING- ###########################################" %str(;) 
       put "WARNING:  The following SAS components are missing! " %str(;) 
       call symputX("packageRequiredErrors", 0, "L") %str(;)              
       do while(iR.next() = 0) %str(;)                                    
         put "WARNING-   " req %str(;)                                    
       end %str(;)                                                        
       put "WARNING:  The package may NOT WORK as expected      " %str(;) 
       put "WARNING:  or even result with ERRORS!               " %str(;) 
       put "WARNING- ###########################################" %str(;) 
       put %str(;)                                           
     end %str(;)                                             
 run %str(;)                                                 
 filename _stinit_ clear %str(;)                             
 options notes source %str(;)                                
 ))*;                                                        
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
 
%if (%str(*)=%superq(cherryPick)) or (dssql in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type libname from the file "dssql.sas" will be included <<;
  %include P948C2DF(_000_libname.dssql.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (dssql_inner in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "dssql_inner.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(dssql_inner)=1, NOTE# Macro dssql_inner exist. It will be overwritten by the macro from the SQLinDS package, ));
  %include P948C2DF(_001_macro.dssql_inner.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sql in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sql.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sql)=1, NOTE# Macro sql exist. It will be overwritten by the macro from the SQLinDS package, ));
  %include P948C2DF(_001_macro.sql.sas) / nosource2;
%end; 

data _null_; 
  call symputX('cherryPick_FCMP', exist('work.SQLinDSfcmp'), 'L'); 
run; 
 
%if (%str(*)=%superq(cherryPick)) or (dssql in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type function from the file "dssql.sas" will be included <<;
  %include P948C2DF(_002_function.dssql.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.sqlindsfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.sqlindsfcmp);)
))
data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro SQLinDSCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for SQLinDS package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `SQLinDSCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260411.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename P948C2DF &ZIP. '&path./sqlinds.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename P948C2DF clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

%if 0 = &cherryPick_FCMP. %then %do;
options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.sqlindsfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%end;
data _null_;                               
  call symputX("cherryPick_KMF", 0, "L");  
run;                                       
data work.SQLinDSkmf;                
length member $ 128; call missing(member); 
if 0 then output;                          
 
%if (%str(*)=%superq(cherryPick)) or (sqlinds in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type kmfsnip from the file "sqlinds.sas" will be included <<;
  member = "_003_kmfsnip.sqlinds.sas"; output;
  %let cherryPick_KMF = %eval(&cherryPick_KMF. + 1);
%end; 

data _null_;
run;
%let temp_noNotes_etc=%sysfunc(getoption(NOTES));
options noNotes;
%if &cherryPick_KMF. %then %do;
filename __KMFgen temp;
data _null_;
  set work.SQLinDSkmf nobs=nobs;
  call symputX("numberKMF",nobs,"L");
  file __KMFgen;
  length _KMF_name_$ 130;
  _KMF_name_ = quote(scan(member,-2,"."));
  put 'end=0; append=0; i+1;'
    / '_KMF_name_[i]=' _KMF_name_ ';'
    / 'do until(end);'
    / ' infile P948C2DF(' member +(-1) ') end=end;'
    / ' input codeLine $char2048. @;'
    / ' if upcase(codeLine) =: "KMFCODEDESC:" then'
    / '   _KMF_desc_[i] = strip(substr(codeLine,13));'
    / ' if upcase(codeLine) =: "KMFCODEEND:" then append=0;'
    / ' if append then'
    / '   do;'
    / '     if lengthn(codeLine) then'
    / '       _KMF_code_[i] = trim(_KMF_code_[i]) !! trim(codeLine) !! CrNl;'
    / '     else _KMF_code_[i] = trim(_KMF_code_[i]) !! CrNl;'
    / '     _KMF_NoLi_[i]+1;'
    / '   end;'
    / ' if upcase(codeLine) =: "KMFCODESTART:" then append=1;'
    / 'end;'
    / '_KMF_code_[i]=substr(_KMF_code_[i],1,lengthn(_KMF_code_[i])-1);'
    ;
run;
data _nulL_;
  file "%sysfunc(pathname(WORK))/%sysfunc(lowcase(&packageName..kmf))" termstr=NL lrecl=32767;
  putlog "INFO: The &packageName. package provides KMF-abbreviations."; 
  putlog   @7 "By default the file with abbreviations is located in:";
  putlog / @9 "%sysfunc(pathname(WORK))/%sysfunc(lowcase(&packageName..kmf))";
  putlog / @7 "To import code abbreviations to your SAS session:";
  putlog   @7 "- in SAS DMS go to: Tools -> Keyboard Macros -> Macros... -> Import... ";
  putlog   @7 "- in SAS EG go to: Program -> Manage Macros and Snippets -> Import... ";
  putlog   @7 "and navigate to the location of the KMF file.";
  putlog / @7 "Should you have any problem with finding the file consider moving";
  putlog   @7 "it to a location of your choice with the help of the following snippet:";
  putlog / @7 "  filename KMFin " "'%sysfunc(pathname(WORK))/%sysfunc(lowcase(&packageName..kmf))'" " lrecl=1 recfm=n;";
  putlog / @7 "  filename KMFout " "'</directory/of/your/choice>/%sysfunc(lowcase(&packageName..kmf))'" " lrecl=1 recfm=n;";
  putlog   @7 '  %put *%sysfunc(fcopy(KMFin, KMFout))*(0=success)*;';
  putlog / "0a"x / " ";
  array _KMF_name_[&numberKMF.] $ 128;
  array _KMF_desc_[&numberKMF.] $ 256;
  array _KMF_seqn_[&numberKMF.] (1:&numberKMF.);
  array _KMF_code_[&numberKMF.] $ 32767;
  array _KMF_NoLi_[&numberKMF.] ;
  array _KMF_Byte_[&numberKMF.] $ 7;
  noDef = symgetn("numberKMF");
  tmpByteD2 = floor(noDef/256);
  tmpByteD1 = noDef - (tmpByteD2*256);
  noDefByte = "KM" !! byte(0) !! byte(2) !! byte(tmpByteD1) !! byte(tmpByteD2) !! byte(0) !! byte(0);
  CrNl=byte(13)!!byte(10);
  %include __KMFgen / &source2.;
  do i = 1 to &numberKMF.;
    X1=lengthn(trim(_KMF_code_[i]));
    X2=lengthn(strip(_KMF_name_[i]));
    X3=lengthn(strip(_KMF_desc_[i]));
    X4=lengthn(put(_KMF_seqn_[i], best3.-l));
    X5=lengthn(put(_KMF_NoLi_[i], best12.-l));
    noChar = sum(X1, X2, X3, X4, X5, 20);
    tmpByteC2 = floor(noChar/256);
    tmpByteC1 = noChar - (tmpByteC2*256);
    _KMF_Byte_[i] = byte(tmpByteC1) !! byte(tmpByteC2) !! byte(0) !! byte(0) !! "252";
  end;
  do i = 1 to &numberKMF.;
    if i=1 then put noDefByte +(-1) @@;
    /* 1*/ put _KMF_Byte_[i];
    /* 2*/ put "3";
    /* 3*/ put _KMF_name_[i];
    /* 4*/ if lengthn(_KMF_desc_[i]) then put _KMF_desc_[i]; else put;
    /* 5*/ put "1"
    /* 6*/   / "332"
    /* 7*/   / "1";
    /* 8*/ put _KMF_NoLi_[i];
    /* 8*/ put _KMF_code_[i];
    /*10*/ put _KMF_seqn_[i];
    /*11*/ put "1";
    ;
  end;
stop;
run;
%symdel numberKMF / noWarn;
filename __KMFgen clear;
%end;
proc delete data=work.SQLinDSkmf; run;
options &temp_noNotes_etc.;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.SQLinDSfcmp.packagemeta ; 
 function SQLinDSMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("2.4.0"));
   if m = 'D' then return(strip("2026-05-11T14:15:07"));
   if m = 'A' then return(strip("Mike Rhoads (RhoadsM1@Westat.com), contributor Bartosz Jablonski"));
   if m = 'M' then return(strip("Bartosz Jablonski (yabwon@gmail.com)"));
   if m = 'T' then return(strip("SQL queries in Data Step"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-05-11T14:15:07"));
   if m = 'S' then return(strip("""BASE SAS SOFTWARE"""));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.sqlindsfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.sqlindsfcmp);)
))
%macro SQLinDSMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(SQLinDSMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#sqlinds(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'SQLinDS(2.4.0)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'SQLinDS(2.4.0)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'SQLinDS(2.4.0)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] SQLinDS(2.4.0)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package SQLinDS, version 2.4.0, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

