filename P948C2DF list;
 %put NOTE- ;
 %put NOTE: Data for package SQLinDS, version 2.4.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-11T14:15:07; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(SQLinDS) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package SQLinDS, version 2.4.0, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
