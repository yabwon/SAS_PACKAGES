/*** HELP START ***//*
This is a help note for `sqlinds` KMF-abbreviation.

The snippet presents a template 
for use of the `%SQL()` macro.

To read help info about the macro 
run he following:
`%helpPackage(SQLinDS,'%sql()')`

*//*** HELP END ***/

kmfCodeDesc:The snippet is a template for use of the `%SQL()` macro. 

kmfCodeStart:

/* To get help info run: 
  %helpPackage(SQLinDS,'%sql()') 
*/

data <output_data_set> ; 
  set %SQL( 
    select 
      <a_list_of_variables>
    from 
      <input_data_set> 
    where 
      <a_where_clause>
    group by
      <grouping_variables>
  );

  <some_4GL_code>

run ;
kmfCodeEnd:
