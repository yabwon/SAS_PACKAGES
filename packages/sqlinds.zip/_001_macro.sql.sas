/*** HELP START ***//*
 
The `%SQL()` macro is the **main** 
macro in the package. The macro allows 
to use SQL queries in the data step.
 
Recommended for *SAS 9.3* and higher.
 
Implementation is based on the article: 
*"Use the Full Power of SAS in Your Function-Style Macros"*
by *Mike Rhoads* (Westat, Rockville), available at:
[https://support.sas.com/resources/papers/proceedings12/004-2012.pdf](https://support.sas.com/resources/papers/proceedings12/004-2012.pdf)

Copy of the article can also be found in *additional content* directory.

### SYNTAX: ###################################################################
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
%sql(<nonempty Proc SQL query code>)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The query code is limited to approximately *32000* bytes.

### EXAMPLES: #################################################################

**EXAMPLE 1**: A simple SQL query.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data class_subset;
  set %SQL(select name, sex, height from sashelp.class where age > 12);
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 2**: A query with dataset options.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data renamed;
  set %SQL(select name, age from sashelp.class 
           where sex = "F")(rename = (age=age2)
           );
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 3**: Proc SQL dictionaries in the data step.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data dictionary;
  set %SQL(select dict.* from dictionary.macros as dict);
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**EXAMPLE 4**: Use Proc SQL to populate hash table. 
               Call to `%SQL()` has to be in double-quotes.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sas
data _null_;
  if 0 then set %SQL(SELECT name, age FROM sashelp.class);

  declare hash H (dataset: "%SQL(SELECT name, age FROM sashelp.class)") ;
  H.defineKey("age");
  H.defineKey("name");
  H.defineDone();

  H.output(dataset:"output");
  stop;
run;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
---

*//*** HELP END ***/


/* Main Package macro */
%MACRO SQL() / PARMBUFF SECURE; 
  %let SYSPBUFF = %superq(SYSPBUFF); /* macroquoting */
  %let SYSPBUFF = %substr(&SYSPBUFF, 2, %LENGTH(&SYSPBUFF) - 2); /* remove brackets */
  %let SYSPBUFF = %superq(SYSPBUFF); /* macroquoting */
  %let SYSPBUFF = %sysfunc(quote(&SYSPBUFF)); /* quotes */
  %put NOTE:*** the query ***; /* print out the query in the log */
  %put NOTE-&SYSPBUFF.;
  %put NOTE-*****************;

  %local UNIQUE_INDEX; /* internal variable, a unique index for views */
    %let UNIQUE_INDEX = &SYSINDEX.; 
  %do;%qsysfunc(dsSQL(&UNIQUE_INDEX., %superq(SYSPBUFF)))%end; /* <-- call dsSQL() function, 
                                                                      see the WORK.SQLinDSfcmp dataset */
%MEND SQL;
